### Todos

1. Update book functionality
2. Delete a book
3. Pagination
4. Fetch only author's book (Backend task)
